/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "LPC17xx.h"
#include "RIT.h"
#include "../led/led.h"

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

extern int led_index, new_attempt;
int num_right = 0, num_wrong = 0;

void RIT_IRQHandler (void)
{					
	if((LPC_GPIO1->FIOPIN & (1<<29)) == 0){	
		/* Joystick UP pressed */
		if (new_attempt == 1)
		{
			if (led_index == 3)
				num_right += 1;
			else
				num_wrong += 1;
		new_attempt = 0;
		LED_Off(led_index);
		}
	}
	else if((LPC_GPIO1->FIOPIN & (1<<28)) == 0){	
		/* Joystick RIGHT pressed */
		if (new_attempt == 1)
		{
			if (led_index == 2)
				num_right += 1;
			else
				num_wrong += 1;
		new_attempt = 0;
		LED_Off(led_index);
		}
	}
	else if((LPC_GPIO1->FIOPIN & (1<<27)) == 0){	
		/* Joystick LEFT pressed */
		if (new_attempt == 1)
		{
			if (led_index == 1)
				num_right += 1;
			else
				num_wrong += 1;
		new_attempt = 0;
		LED_Off(led_index);
		}
	}
	else if((LPC_GPIO1->FIOPIN & (1<<26)) == 0){	
		/* Joystick DOWN pressed */
		if (new_attempt == 1)
		{
			if (led_index == 0)
				num_right += 1;
			else
				num_wrong += 1;
		new_attempt = 0;
		LED_Off(led_index);
		}
	}
	
  LPC_RIT->RICTRL |= 0x1;	/* clear interrupt flag */
	
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/

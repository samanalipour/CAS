/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_timer.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    timer.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "LPC17xx.h"
#include "timer.h"
extern int nextElementLCG(int seed, int multiplier, int increment, int constant, int module);
int led_index = 0;
volatile int new_attempt = 0;	
extern int num_right, num_wrong;

/******************************************************************************
** Function name:		Timer0_IRQHandler
**
** Descriptions:		Timer/Counter 0 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

/*
0: led 11		joystick down: GPIO1.26
1: led 10		joystick left: GPIO1.27
2: led 9		joystick right: GPIO1.28
3: led 8		joystick up: GPIO1.29
*/

void TIMER0_IRQHandler (void)
{
	static int value = 1;
	static int index = 0;
	
	if (index < 20)
	{
		led_index = value % 4;
		LED_Off(led_index);
		value = nextElementLCG(value, 131, 7, index, 255);
		new_attempt = 1;
		led_index = value % 4;
		LED_On(led_index);
		index ++;
	}
	else if (index == 20)		/* end game */
	{
		if (num_right > num_wrong)
			LED_On(7);					/* led 4 on: win */
		else
			LED_On(6);					/* led 5 on: loss */
	}
  LPC_TIM0->IR = 1;			/* clear interrupt flag */
  return;
}


/******************************************************************************
** Function name:		Timer1_IRQHandler
**
** Descriptions:		Timer/Counter 1 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
void TIMER1_IRQHandler (void)
{
  LPC_TIM1->IR = 1;			/* clear interrupt flag */
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
